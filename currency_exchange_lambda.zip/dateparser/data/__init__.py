from dateparser.data import date_translation_data

from .languages_info import language_locale_dict, language_order
