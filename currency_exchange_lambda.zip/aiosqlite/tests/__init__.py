# Copyright 2022 Amethyst Reese
# Licensed under the MIT license

from .smoke import SmokeTest
